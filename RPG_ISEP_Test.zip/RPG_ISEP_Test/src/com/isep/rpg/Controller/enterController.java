package com.isep.rpg.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class enterController implements Initializable {
    //static ObservableList<String> choixdeherosList = FXCollections.observableArrayList("Mage","Healer","Hunter");

//    private static ChoiceBox<String> choixdeheros=new ChoiceBox<>();
//    static {
//        choixdeheros.setItems(choixdeherosList);
//
//    }
    @FXML
    ChoiceBox<String> choixdeheros;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        choixdeheros.getItems().addAll("Healer    ","Mage    ","Hunter    ","Warrior    ");
    }
}
