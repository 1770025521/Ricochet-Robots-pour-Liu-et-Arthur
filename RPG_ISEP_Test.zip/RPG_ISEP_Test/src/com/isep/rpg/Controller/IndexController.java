package com.isep.rpg.Controller;


import com.isep.rpg.scene.Enter;
import com.isep.rpg.scene.Index;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class IndexController {

    @FXML
    private ImageView startGame;

    @FXML
    void mouseClickedStartGame(MouseEvent event) {

        FXMLLoader fxmlLoader = new FXMLLoader(Enter.class.getResource("/fxml/enter.fxml"));
        Scene scene = null;
        try {
            scene = new Scene(fxmlLoader.load());
        } catch (IOException e) {
            e.printStackTrace();
        }
        Stage stage = new Stage();
        stage.setTitle("Main de RPG");
        stage.getIcons().add(new Image("resourse\\image\\rpgicon.png"));
        stage.setScene(scene);
        stage.show();


        Stage stage1 = (Stage)startGame.getScene().getWindow();
        stage1.close();




    }


    @FXML
    void mouseEnteredStartGame(MouseEvent event) {
        startGame.setOpacity(0.5);

    }

    @FXML
    void mouseExitedStartGame(MouseEvent event) {
        startGame.setOpacity(1);
    }

}
